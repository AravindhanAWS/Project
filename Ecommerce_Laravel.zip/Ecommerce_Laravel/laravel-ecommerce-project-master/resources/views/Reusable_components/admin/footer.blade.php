 
<!-- Footer -->
<footer class="page-footer font-small stylish-color-white pt-4" style="width:100%;color:black;position:fixed;">

 
   

  <!-- Copyright -->
  <div  class="footer-copyright text-center py-3" style=background:black>
        <div class="row" style="font-size:15px;">
            <div class="col-md-3">
                    © 2020 Copyright:
                <a href="https://rahulvijayam.com/"> Gainaloe</a>
            </div>
            
            <div  id="developedbybtaoteam" class="col-md-9" >
                 <span class="px-5"> Developed by Rahul Vijayanagaram </span>
            </div>
        </div>
  
    
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->
 